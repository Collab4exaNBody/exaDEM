//#pragma xstamp_cuda_enable

#include <exanb/core/operator.h>
#include <exanb/core/operator_slot.h>
#include <exanb/core/operator_factory.h>
#include <exanb/core/make_grid_variant_operator.h>
#include <exanb/core/parallel_grid_algorithm.h>
#include <exanb/core/grid.h>	
#include <exanb/core/domain.h>


#include <exanb/core/basic_types.h>
#include <exanb/core/basic_types_operators.h>
#include <exanb/core/basic_types_stream.h>
#include <onika/memory/allocator.h> // for ONIKA_ASSUME_ALIGNED macro
#include <exanb/compute/compute_pair_optional_args.h>
#include <vector>
#include <iomanip>

//#include <exaDEM/interaction_functor.h>


#include <exanb/compute/compute_cell_particles.h>
#include <exaDEM/face.h>

#include <exaDEM/face.h>

#include <exaDEM/stl_mesh.h>
//#include <exaDEM/stl_meshGPU.h>
//#include <exaDEM/stl_meshesGPU.h>

#include <exaDEM/hooke_stl_meshes.h>
//#include <exaDEM/hooke_stl_meshesGPU.h>
//#include <exaDEM/hooke_stl_meshesGPU2.h>
//#include <exaDEM/hooke_stl_meshesGPU3.h>

#include <exaDEM/mutexes.h>


#include <onika/cuda/cuda.h> // mots cles specifiques
#include <onika/memory/allocator.h> // cudaMMVector

#include <exaDEM/common_compute_kernels.h>
#include <exaDEM/compute_hooke_force.h>

#include <exaDEM/interaction.h>

#include <mpi.h>

namespace exaDEM
{
	using namespace exanb;
	
	//template< class GridT > __global__ void kernel_stl_mesh(GridT g){
	//	const auto cells = g.cells();
	//}
	
	//template< class GridT > __global__ void kernel_carlo(int a, GridT* cells){
	//}
	
	/**template < class GridT > __global__ void ApplyHookeSTLMeshesKernel(GridT* cells, Interactions ints, double dt, double kt, double kn, double kr, double mu, double damprate, int size){
		int idx = threadIdx.x + blockIdx.x * blockDim.x;
		if(idx < size){
		auto& _nx = ints.nx;
		auto* nx_ = onika::cuda::vector_data(_nx);
		auto& _ny = ints.ny;
		auto* ny_ = onika::cuda::vector_data(_ny);
		auto& _nz = ints.nz;
		auto* nz_ = onika::cuda::vector_data(_nz);
		auto& _posx = ints.posx;
		auto* posx_ = onika::cuda::vector_data(_posx);
		auto& _posy = ints.posy;
		auto* posy_ = onika::cuda::vector_data(_posy);
		auto& _posz = ints.posz;
		auto* posz_ = onika::cuda::vector_data(_posz);
		auto& _type = ints.type;
		auto* type_ = onika::cuda::vector_data(_type);
		auto& _cell = ints.cell_i;
		auto* cell_i_ = onika::cuda::vector_data(_cell);
		auto& _p = ints.p_i;
		auto* p_i_ = onika::cuda::vector_data(_p);
		auto& _rx = ints.rx;
		auto* rx_ = onika::cuda::vector_data(_rx);
		auto& _ry = ints.ry;
		auto* ry_ = onika::cuda::vector_data(_ry);
		auto& _rz = ints.rz;
		auto* rz_ = onika::cuda::vector_data(_rz);
		auto& _vx = ints.vx;
		auto* vx_ = onika::cuda::vector_data(_vx);
		auto& _vy = ints.vy;
		auto* vy_ = onika::cuda::vector_data(_vy);
		auto& _vz = ints.vz;
		auto* vz_ = onika::cuda::vector_data(_vz);
		auto& _vrotx = ints.vrotx;
		auto* vrotx_ = onika::cuda::vector_data(_vrotx);
		auto& _vroty = ints.vroty;
		auto* vroty_ = onika::cuda::vector_data(_vroty);
		auto& _vrotz = ints.vrotz;
		auto* vrotz_ = onika::cuda::vector_data(_vrotz);
		auto& _rad = ints.radius;
		auto* radius_ = onika::cuda::vector_data(_rad);
		auto& _fx = ints.fx;
		auto* fx_ = onika::cuda::vector_data(_fx);
		auto& _fy = ints.fy;
		auto* fy_ = onika::cuda::vector_data(_fy);
		auto& _fz = ints.fz;
		auto* fz_ = onika::cuda::vector_data(_fz);
		auto& _mass = ints.mass;
		auto* mass_ = onika::cuda::vector_data(_mass);
		auto& _momx = ints.momx;
		auto* momx_ = onika::cuda::vector_data(_momx);
		auto& _momy = ints.momy;
		auto* momy_ = onika::cuda::vector_data(_momy);
		auto& _momz = ints.momz;
		auto* momz_ = onika::cuda::vector_data(_momz);
		auto& _ftx = ints.ftx;
		auto* ftx_ = onika::cuda::vector_data(_ftx);
		auto& _fty = ints.fty;
		auto* fty_ = onika::cuda::vector_data(_fty);
		auto& _ftz = ints.ftz;
		auto* ftz_ = onika::cuda::vector_data(_ftz);
		
		double nx = nx_[idx];
		double ny = ny_[idx];
		double nz = nz_[idx];
		double posx = posx_[idx];
		double posy = posy_[idx];
		double posz = posz_[idx];
		int type = type_[idx];
		size_t cell_i = cell_i_[idx];
		uint16_t p_i = p_i_[idx];
		double rx = rx_[idx];
		double ry = ry_[idx];
		double rz = rz_[idx];
		double vx = vx_[idx];
		double vy = vy_[idx];
		double vz = vz_[idx];
		double vrotx = vrotx_[idx];
		double vroty = vroty_[idx];
		double vrotz = vrotz_[idx];
		double radius = radius_[idx];
		double fx = fx_[idx];
		double fy = fy_[idx];
		double fz = fz_[idx];
		double mass = mass_[idx];
		double momx = momx_[idx];
		double momy = momy_[idx];
		double momz = momz_[idx];
		double ftx = ftx_[idx];
		double fty = fty_[idx];
		double ftz = ftz_[idx];
		
		Vec3d pos_proj;
		double m_vel = 0;
		Vec3d pos = {rx, ry, rz};
		Vec3d vel = {vx, vy, vz};
		Vec3d normal = {nx, ny, nz};
		Vec3d contact_position = {posx, posy, posz};
		
		if(type == 0)
		{
			pos_proj = dot(pos, normal) * normal;
		} else if(type == 1){
			pos_proj = pos;
		}
		
		Vec3d vec_n = pos_proj - contact_position;
		double n = norm(vec_n);
		vec_n = vec_n/n;
		const double dn = n - radius;
		Vec3d rigid_surface_center = contact_position;
		const Vec3d rigid_surface_velocity = normal * m_vel;
		constexpr Vec3d rigid_surface_angular_velocity = {0.0, 0.0, 0.0};
		
		Vec3d f = {0.0, 0.0, 0.0};
		constexpr double meff = 1;
		
		Vec3d ft = {ftx, fty, ftz};
		Vec3d mom = {momx, momy, momz};
		Vec3d vrot = {vrotx, vroty, vrotz};
		
		exaDEM::hooke_force_core_v2(dn, vec_n, dt, kn, kt, kr, mu, damprate, meff, ft, contact_position, pos_proj, vel, f, mom, vrot, rigid_surface_center, rigid_surface_velocity, rigid_surface_angular_velocity);
		
		cells[cell_i][field::fx][p_i]+= f.x;
		cells[cell_i][field::fy][p_i]+= f.y;
		cells[cell_i][field::fz][p_i]+= f.z;
		cells[cell_i][field::mom][p_i]= mom;
		cells[cell_i][field::friction][p_i]= ft;   		
	}
	}*/
	
	template<
		class GridT,
					class = AssertGridHasFields< GridT, field::_fx, field::_fy, field::_fz, field::_friction >
						>
						class ApplyHookeSTLMeshesOperator : public OperatorNode
						{

							using ComputeFields = FieldSet< field::_rx ,field::_ry ,field::_rz, field::_vx ,field::_vy ,field::_vz, field::_vrot, field::_radius , field::_fx ,field::_fy ,field::_fz, field::_mass, field::_mom, field::_friction >;
							static constexpr ComputeFields compute_field_set {};
							ADD_SLOT( MPI_Comm , mpi      , INPUT , MPI_COMM_WORLD);
							ADD_SLOT( GridT  , grid    , INPUT_OUTPUT );
							ADD_SLOT( Domain , domain  , INPUT , REQUIRED );
							ADD_SLOT( onika::memory::CudaMMVector< exaDEM::stl_mesh > , stl_collection, INPUT_OUTPUT , DocString{"list of verticies"});
							ADD_SLOT( double  , dt                		, INPUT 	, REQUIRED 	, DocString{"Timestep of the simulation"});
							ADD_SLOT( double  , kt  			, INPUT 	, REQUIRED 	, DocString{"Parameter of the force law used to model contact cyclinder/sphere"});
							ADD_SLOT( double  , kn  			, INPUT 	, REQUIRED 	, DocString{"Parameter of the force law used to model contact cyclinder/sphere"} );
							ADD_SLOT( double  , kr  			, INPUT 	, REQUIRED 	, DocString{"Parameter of the force law used to model contact cyclinder/sphere"});
							ADD_SLOT( double  , mu  			, INPUT 	, REQUIRED 	, DocString{"Parameter of the force law used to model contact cyclinder/sphere"});
							ADD_SLOT( double  , damprate  			, INPUT 	, REQUIRED 	, DocString{"Parameter of the force law used to model contact cyclinder/sphere"});
							//!ADD_SLOT( exaDEM::stl_meshes, meshes, INPUT_OUTPUT, DocString{"Collection of meshes from stl files"});
							ADD_SLOT( mutexes,  locks                       , INPUT_OUTPUT  );
 
							public:
							inline std::string documentation() const override final
							{
								return R"EOF(
    	    			)EOF";
							}
							

							inline void execute () override final
							{
								//printf("DEBUT\n");
								auto& collection = *stl_collection;
							
								auto& g = *grid;
								const auto cells = g.cells();
								const size_t n_cells = g.number_of_cells();
								const IJK dims = g.dimension();
								const int gl = g.ghost_layers();
								mutexes& locker = *locks;
								
								Interactions I;
								
								
								
								for(auto& mesh : collection){
								
									auto& ind= mesh.indexes;
									
									std::vector< std::vector< Interaction >> interactions_cells;
								
									interactions_cells.resize(n_cells);
									//printf("UN\n");
#	pragma omp parallel
									{
										GRID_OMP_FOR_BEGIN(dims-2*gl,_,block_loc, schedule(static))
										{
											IJK loc_a = block_loc + gl;
											size_t cell_a = grid_ijk_to_index( dims , loc_a );
											if(ind[cell_a].size()>0){
												const int n_particles = cells[cell_a].size();
												const uint64_t* __restrict__ id_a = cells[cell_a][ field::id ]; ONIKA_ASSUME_ALIGNED(id_a);
												const auto* __restrict__ rx_a = cells[cell_a][ field::rx ]; ONIKA_ASSUME_ALIGNED(rx_a);
												const auto* __restrict__ ry_a = cells[cell_a][ field::ry ]; ONIKA_ASSUME_ALIGNED(ry_a);
												const auto* __restrict__ rz_a = cells[cell_a][ field::rz ]; ONIKA_ASSUME_ALIGNED(rz_a);
												const auto* __restrict__ radius_a = cells[cell_a][ field::radius ]; ONIKA_ASSUME_ALIGNED(radius_a);
												const auto* __restrict__ vx_a = cells[cell_a][ field::vx ]; ONIKA_ASSUME_ALIGNED(vx_a);
												const auto* __restrict__ vy_a = cells[cell_a][ field::vy ]; ONIKA_ASSUME_ALIGNED(vy_a);
												const auto* __restrict__ vz_a = cells[cell_a][ field::vz ]; ONIKA_ASSUME_ALIGNED(vz_a);
												const auto* __restrict__ vrot_a = cells[cell_a][ field::vrot ]; ONIKA_ASSUME_ALIGNED(vrot_a);
												const auto* __restrict__ fx_a = cells[cell_a][ field::fx ]; ONIKA_ASSUME_ALIGNED(fx_a);
												const auto* __restrict__ fy_a = cells[cell_a][ field::fy ]; ONIKA_ASSUME_ALIGNED(fy_a);
												const auto* __restrict__ fz_a = cells[cell_a][ field::fz ]; ONIKA_ASSUME_ALIGNED(fz_a);
												const auto* __restrict__ mass_a = cells[cell_a][ field::mass ]; ONIKA_ASSUME_ALIGNED(mass_a);
												const auto* __restrict__ mom_a = cells[cell_a][ field::mom ]; ONIKA_ASSUME_ALIGNED(mom_a);
												const auto* __restrict__ ft_a = cells[cell_a][ field::friction ]; ONIKA_ASSUME_ALIGNED(ft_a);
												
												bool is_face = false;
												bool do_edge = false;
												for(int particle = 0; particle < n_particles; particle++){
													
													for(auto f : ind[cell_a]){
														Face face = mesh.m_data[f];
														bool contact= false;
														bool potential= false;
														Vec3d position= {0,0,0};
														face.contact_face_sphere(rx_a[particle], ry_a[particle], rz_a[particle], radius_a[particle], contact, potential, position);
														if(contact){ 
															is_face = true;
															Interaction i = {face.normal.x, face.normal.y, face.normal.z, position.x, position.y, position.z, 0, cell_a, id_a[particle], rx_a[particle], ry_a[particle], rz_a[particle], vx_a[particle], vy_a[particle], vz_a[particle], vrot_a[particle].x, vrot_a[particle].y, vrot_a[particle].z, radius_a[particle], fx_a[particle], fy_a[particle], fz_a[particle], mass_a[particle], mom_a[particle].x, mom_a[particle].y, mom_a[particle].z, ft_a[particle].x, ft_a[particle].y, ft_a[particle].z}; 
															interactions_cells[cell_a].push_back(i);
															printf("CONTACT, CELL: %d, PARTICLE: %d\n", cell_a, particle);
															getchar();
															//cells[cell_a][field::mass][id]=0;
														}
														
														do_edge = do_edge || potential;
													}
													if( is_face == false && do_edge ){
														for( auto f : ind[cell_a]){
															Face face = mesh.m_data[f];
															bool contact= false;
															Vec3d position= {0, 0, 0};
															face.contact_edge_sphere(rx_a[particle], ry_a[particle], rz_a[particle], radius_a[particle], contact, position);
															if(contact){
																Interaction i = {face.normal.x, face.normal.y, face.normal.z, position.x, position.y, position.z, 1, cell_a, id_a[particle], rx_a[particle], ry_a[particle], rz_a[particle], vx_a[particle], vy_a[particle], vz_a[particle], vrot_a[particle].x, vrot_a[particle].y, vrot_a[particle].z, radius_a[particle], fx_a[particle], fy_a[particle], fz_a[particle], mass_a[particle], mom_a[particle].x, mom_a[particle].y, mom_a[particle].z, ft_a[particle].x, ft_a[particle].y, ft_a[particle].z}; 
																interactions_cells[cell_a].push_back(i);
																printf("CONTACT, CELL: %d, PARTICLE: %d\n", cell_a, particle);
																getchar();
															}
														}
													}
												}
											}
										}
										GRID_OMP_FOR_END
									}
									//printf("DEUX\n");
									for(auto intc: interactions_cells){
										if(intc.size() > 0){
											for(auto interaction : intc){
												I.add(interaction);
											}
										}
									}
								}
								
								int size = I.nb_interactions;
								int blockSize = 32;
								//int numBlocks;dddd
								//if(size % size == 0){ numBlocks = size/blockSize;}
								//else { numBlocks = size/blockSize + 1;}
								
								//ApplyHookeSTLMeshesKernel<<<numBlocks, blockSize>>>(cells, I, *dt, *kt, *kn, *kr, *mu, *damprate, size)	;						
								
						}
					};


	// this helps older versions of gcc handle the unnamed default second template parameter
	template <class GridT> using ApplyHookeSTLMeshesOperatorTemplate = ApplyHookeSTLMeshesOperator<GridT>;

	// === register factories ===  
	CONSTRUCTOR_FUNCTION
	{
		OperatorNodeFactory::instance()->register_factory( "apply_hooke_stl_meshes2", make_grid_variant_operator< ApplyHookeSTLMeshesOperatorTemplate > );
	}
};

