#pragma once
#include <exanb/core/basic_types.h>
#include <exaDEM/common_compute_kernels.h>
#include <exaDEM/compute_hooke_force.h>
#include <exaDEM/face.h>
//#include <exaDEM/stl_mesh.h>
//#include <exaDEM/stl_meshGPU.h>
#include <exaDEM/stl_meshesGPU.h>
#include <cstdio> 

//#include <thrust/host_vector.h>
//#include <thrust/device_vector.h> 
//#include <thrust/universal_vector.h>

#include <onika/cuda/cuda.h> // mots cles specifiques
#include <onika/memory/allocator.h> // cudaMMVector
#include <onika/cuda/stl_adaptors.h>


namespace exaDEM
{
	using exanb::Vec3d;
	
	using namespace exanb; 
		
	/**
	 * @brief Functor for applying Hooke's law to multiple Faces within a grid.
	 *
	 * The `ApplyHookeSTLMeshesFunctor` struct represents a functor used to apply Hooke's law to particles interacting
	 * with multiple STL meshes within a grid. It is designed to be used as an operator in simulations. The functor takes
	 * various parameters and updates forces and torques acting on the particles.
	 *
	 * @tparam GridT The type of grid.
	 */
	struct ApplyHookeSTLMeshesFunctor2
	{
		
		//exaDEM::stl_mesh*  pmeshes;/**< Meshes's data.*/
		//long unsigned int smeshes;/** Number of meshes.*/
		stl_meshes mesh; 
		double m_dt; /**< Time step. */
		double m_kt; /**< Tangential spring constant. */
		double m_kn; /**< Normal spring constant. */
		double m_kr; /**< Rotational spring constant. */
		double m_mu; /**< Friction coefficient. */
		double m_dampRate; /**< Damping rate. */
		bool* contacts;
		double* px;
		double* py;
		double* pz;
		bool* cells2;
		
		
		/**
		 * @brief Operator for applying Hooke's law.
		 *
		 * This operator applies Hooke's law to particles interacting with multiple STL meshes within a grid. It updates
		 * forces and torques acting on the particles based on the specified parameters and properties.
		 *
		 * @param cell_idx The cell index.
		 * @param a_rx The x-coordinate of the particle's position.
		 * @param a_ry The y-coordinate of the particle's position.
		 * @param a_rz The z-coordinate of the particle's position.
		 * @param a_vx The x-component of the particle's velocity.
		 * @param a_vy The y-component of the particle's velocity.
		 * @param a_vz The z-component of the particle's velocity.
		 * @param a_vrot The rotational velocity of the particle.
		 * @param a_particle_radius The radius of the particle.
		 * @param a_fx Reference to store the x-component of the calculated force.
		 * @param a_fy Reference to store the y-component of the calculated force.
		 * @param a_fz Reference to store the z-component of the calculated force.
		 * @param a_mass The mass of the particle.
		 * @param a_mom Reference to store the angular momentum.
		 * @param a_ft Reference to store the torque.
		 */
		ONIKA_HOST_DEVICE_FUNC 
		inline void operator () (
				const size_t cell_idx,
				const double a_rx, const double a_ry, const double a_rz,
				const double a_vx, const double a_vy, const double a_vz,
				Vec3d& a_vrot, 
				double a_particle_radius,
				double& a_fx, double& a_fy, double& a_fz, 
				const double a_mass,
				Vec3d& a_mom,
				Vec3d& a_ft) const
		{
			
			
				auto& v_x = mesh.vx_GPU;
				auto* vx= onika::cuda::vector_data(v_x);
				
				auto& v_y= mesh.vy_GPU;
				auto* vy= onika::cuda::vector_data(v_y);
				
				auto& v_z= mesh.vz_GPU;
				auto* vz= onika::cuda::vector_data(v_z);
				
				auto& n_x= mesh.nx_GPU;
				auto* nx= onika::cuda::vector_data(n_x);
				
				auto& n_y= mesh.ny_GPU;
				auto* ny= onika::cuda::vector_data(n_y);
				
				auto& n_z= mesh.nz_GPU;
				auto* nz= onika::cuda::vector_data(n_z);
				
				auto& off= mesh.offsets_GPU;
				auto* offsets= onika::cuda::vector_data(off);
				
				auto& cf= mesh.compute_face;
				auto* compute_face= onika::cuda::vector_data(cf);
				
				int nb_max_faces= mesh.nb_max_faces;
				int nb_cells= mesh.nb_cells;
				
				
				
				int idx1= cell_idx;
				int idx2= cell_idx;
					
						for(int i = 0; i < nb_max_faces; i++){
							
							Vec3d normal= {nx[idx1], ny[idx1], nz[idx1]};
							bool contact= false;
							Vec3d position= {0,0,0};
							
							//CONTACT_EDGE_SPHERE
							const Vec3d center = {a_rx,a_ry,a_rz};
							
							int index_start= idx2;
							for (size_t iva = 0; iva < 2; ++iva) {
								Vec3d p1 = {vx[idx2], vy[idx2], vz[idx2]};
								Vec3d p2 = {vx[idx2 + nb_cells], vy[idx2 + nb_cells], vz[idx2 + nb_cells]};
								Vec3d edge = p2 - p1;
								Vec3d sphereToEdge = center - p1;

								double distanceToEdge = length(exanb::cross(edge, sphereToEdge)) / length(edge);

								if (distanceToEdge <= a_particle_radius && exanb::dot(sphereToEdge, edge) > 0 && exanb::dot(sphereToEdge - edge, edge) < 0) {
									auto n_edge = edge / exanb::norm(edge);
									Vec3d contact_position = p1 + n_edge * dot(sphereToEdge, n_edge);
									contact = true;
									position = contact_position;
								}
								idx2= idx2 + nb_cells;
							}
							
							Vec3d p1 = {vx[idx2], vy[idx2], vz[idx2]};
							Vec3d p2 = {vx[index_start], vy[index_start], vz[index_start]};
							Vec3d edge = p2 - p1;
							Vec3d sphereToEdge = center - p1;

							double distanceToEdge = length(exanb::cross(edge, sphereToEdge)) / length(edge);

							if (distanceToEdge <= a_particle_radius && exanb::dot(sphereToEdge, edge) > 0 && exanb::dot(sphereToEdge - edge, edge) < 0) {
								auto n_edge = edge / exanb::norm(edge);
								Vec3d contact_position = p1 + n_edge * dot(sphereToEdge, n_edge);
								contact = true * compute_face[idx1] * cells2[cell_idx];
								position = contact_position;
							}
							//if(contact)
							//{
							//}
							contacts[idx1]= contact || contacts[idx1];
							px[idx1]= position.x;
							py[idx1]= position.y;
							pz[idx1]= position.z;
							idx1= idx1 + nb_cells;
							idx2= idx2 + nb_cells;
						}
					
				//}
			//}
		}
		
		
		
	};
}


namespace exanb
{
	template<> struct ComputeCellParticlesTraits<exaDEM::ApplyHookeSTLMeshesFunctor2>
	{
		static inline constexpr bool RequiresBlockSynchronousCall = false;
		static inline constexpr bool CudaCompatible = true	;
	};

	template<> struct ComputeCellParticlesTraitsUseCellIdx<exaDEM::ApplyHookeSTLMeshesFunctor2>
	{
		static inline constexpr bool UseCellIdx = true;
	};
}
