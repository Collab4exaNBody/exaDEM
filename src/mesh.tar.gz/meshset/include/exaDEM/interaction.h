#pragma once

#include <exanb/core/basic_types.h>

#include <onika/cuda/cuda.h> // mots cles specifiques
#include <onika/memory/allocator.h> // cudaMMVector
#include <onika/cuda/stl_adaptors.h>
#include <exanb/core/basic_types.h>

//#include <exanb/core/grid.h>

namespace exaDEM
{
	using namespace exanb;
	
	struct Interaction
	{
		int p_i;
		size_t cell_i;
		double nx;
		double ny;
		double nz;
		double offset;
		onika::memory::CudaMMVector<Vec3d> vertices;
	};
	
	struct Interaction_Deux
	{
		int p_i;
		size_t cell_i;
		std::vector< int > faces_idx;
		
	};
	
	
	struct Interactions_inter
	{
		onika::memory::CudaMMVector<int> p_i;
		onika::memory::CudaMMVector<size_t> cell_i;
		onika::memory::CudaMMVector< onika::memory::CudaMMVector<double>> nx;
		onika::memory::CudaMMVector< onika::memory::CudaMMVector<double>> ny;
		onika::memory::CudaMMVector< onika::memory::CudaMMVector<double>> nz;
		onika::memory::CudaMMVector< onika::memory::CudaMMVector<double>> offsets;
		onika::memory::CudaMMVector< onika::memory::CudaMMVector< onika::memory::CudaMMVector<Vec3d>>> vertices;
		
		
		/**void add( Interaction_Deux i ){
			p_i.push_back(i.p_i);
			cell_i.push_back(i.cell_i);
			
			nx.resize(nx.size()+1);
			ny.resize(ny.size()+1);
			nz.resize(nz.size()+1);
			offsets.resize(offsets.size() + 1);
			vertices.resize(vertices.size() + 1);
			vertices[vertices.size() - 1].resize(i.nx.size());
			
			for(int j = 0; j < i.nx.size(); j++){
				nx[nx.size() - 1].push_back(i.nx[j]);
				ny[ny.size() - 1].push_back(i.ny[j]);
				nz[nz.size() - 1].push_back(i.nz[j]);
				offsets[offsets.size() - 1].push_back(i.offsets[j]);
				for(int z = 0; z < i.vertices[j].size(); z++){
					vertices[vertices.size() - 1][j].push_back(i.vertices[j][z]);
				}
			}
		}*/
	};
	
	struct Interactions
	{
		int nb_particles;
		onika::memory::CudaMMVector<int> p_i;//Stockage des particules
		onika::memory::CudaMMVector<size_t> cell_i;//Stockage des cellules
		onika::memory::CudaMMVector<int> faces;
		onika::memory::CudaMMVector<int> start_particle;
		onika::memory::CudaMMVector<int> end_particle;
		onika::memory::CudaMMVector<int> num_faces;
		
		onika::memory::CudaMMVector<double> nx;//Coordonnée x du vecteur normal de la face
		onika::memory::CudaMMVector<double> ny;//Coordonnée y du vecteur normal de la face
		onika::memory::CudaMMVector<double> nz;//Coordonnée z du vecteur normal de la face
		onika::memory::CudaMMVector<double> offsets;//Offset de la face
		onika::memory::CudaMMVector<int> start_face;
		onika::memory::CudaMMVector<int> end_face;
		onika::memory::CudaMMVector<int> num_vertices;
		onika::memory::CudaMMVector<double> vertex_x;
		onika::memory::CudaMMVector<double> vertex_y;
		onika::memory::CudaMMVector<double> vertex_z;
		
		void reset(){
			nb_particles = 0;
			p_i.resize(0);
			cell_i.resize(0);
			nx.resize(0);
			ny.resize(0);
			nz.resize(0);
			start_particle.resize(0);
			end_particle.resize(0);
			offsets.resize(0);
			start_face.resize(0);
			end_face.resize(0);
			vertex_x.resize(0);
			vertex_y.resize(0);
			vertex_z.resize(0);
			num_faces.resize(0);
			num_vertices.resize(0);
			faces.resize(0);
		}
		
		
		void add_particle(Interaction_Deux i){
			p_i.push_back(i.p_i);
			cell_i.push_back(i.cell_i);
			num_faces.push_back(i.faces_idx.size());
			if(nb_particles == 0){
				start_particle.push_back(0);
			} else {
				start_particle.push_back(end_particle.back());
			}
			end_particle.push_back(start_particle.back() + num_faces.back());			
			for(int face = 0; face < num_faces.back(); face++){
				faces.push_back(i.faces_idx[face]);
			}
			nb_particles++;
		}
		
		void add_mesh(int nf,
				std::vector<double> nx_,
				std::vector<double> ny_,
				std::vector<double> nz_,
				std::vector<double> offsets_,
				std::vector<int> start_face_,
				std::vector<int> end_face_,
				std::vector<int> num_vertices_,
				std::vector<double> vx,
				std::vector<double> vy,
				std::vector<double> vz)
		{
			for(int i = 0; i < nf; i++){
				nx.push_back(nx_[i]);
				ny.push_back(ny_[i]);
				nz.push_back(nz_[i]);
				offsets.push_back(offsets_[i]);
				int start = start_face_[i];
				start_face.push_back(start_face_[i]);
				end_face.push_back(end_face_[i]);
				int size = num_vertices_[i];
				num_vertices.push_back(size);
				for(int j = 0; j < size; j++){
					vertex_x.push_back(vx[start+j]);
					vertex_y.push_back(vy[start+j]);
					vertex_z.push_back(vz[start+j]);
				}
			}
		}
	
	};
		
	
};
